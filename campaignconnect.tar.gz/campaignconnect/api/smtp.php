<?php
// Stub API for SMTP accounts
header('Content-Type: application/json');
echo json_encode(['message' => 'SMTP API not implemented']);