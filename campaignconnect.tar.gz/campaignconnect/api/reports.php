<?php
// Stub API for reports
header('Content-Type: application/json');
echo json_encode(['message' => 'Reports API not implemented']);