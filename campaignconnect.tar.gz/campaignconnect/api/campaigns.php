<?php
// Stub API for campaigns
header('Content-Type: application/json');
echo json_encode(['message' => 'Campaign API is not implemented.']);