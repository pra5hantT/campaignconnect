<?php
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();
$title = 'Link Tracking';

include __DIR__ . '/includes/header.php';
?>
<h3>Link Tracking</h3>
<p>This feature is currently under development.</p>

<?php include __DIR__ . '/includes/footer.php'; ?>