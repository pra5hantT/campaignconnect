<?php
?>
    </div><!-- /.container-fluid -->
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha384-JuNPV+Zynf+DN6/giFxk/wphqni9XBFBGTNb3KPcVyQP9cK3UByyILmTq7kLWYtQ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-mfKQ5OdqNDGcCLb/svW7k6kYTxH8+3hMfZ3OLkEmBV2Pm4b0M5k6h+W49CexqkfG" crossorigin="anonymous"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/forms.js"></script>
    <script src="assets/js/campaigns.js"></script>
    <script src="assets/js/contacts.js"></script>
    <script src="assets/js/templates.js"></script>
    <script src="assets/js/reports.js"></script>
</body>
</html>